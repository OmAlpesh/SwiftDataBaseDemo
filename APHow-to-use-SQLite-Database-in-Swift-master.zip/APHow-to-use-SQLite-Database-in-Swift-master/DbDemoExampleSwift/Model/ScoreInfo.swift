//
//  ScoreInfo.swift
//  DbDemoExampleSwift
//
//  Created by alpesh patel on 4/27/17.
//  Copyright © 2017 TheAppGuruz-New-6. All rights reserved.
//

import UIKit

class ScoreInfo: NSObject {

    var playerId: String = String()
    var playperName: String = String()
    var playerScore: String = String()

}
