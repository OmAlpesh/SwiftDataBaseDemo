//
//  SQLiteWrapper.h
//  SQLiteWrapper
//
//  Created by Chris Wagner on 11/26/15.
//  Copyright © 2015 Razeware LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SQLiteWrapper.
FOUNDATION_EXPORT double SQLiteWrapperVersionNumber;

//! Project version string for SQLiteWrapper.
FOUNDATION_EXPORT const unsigned char SQLiteWrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SQLiteWrapper/PublicHeader.h>


