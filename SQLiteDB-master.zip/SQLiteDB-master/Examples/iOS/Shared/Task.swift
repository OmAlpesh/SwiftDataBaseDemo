//
//  Task.swift
//  SQLiteDB-iOS


#if os(iOS)
	import UIKit
#else
	import AppKit
#endif

class Task:SQLiteInstance {
    var id : String = ""
	var task : String = ""
	var categoryID : String = ""
}
