//
//  CategoryViewController.swift
//  SQLiteDB-iOS
//


import UIKit

class CategoryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var table:UITableView!
    
    var data = [Category]()
    let sqlObj = SQLiteInstance()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated:Bool) {
        super.viewWillAppear(animated)
        
        sqlObj.setDatabse("data.db")
        displayDetails()
    }
    
    func displayDetails(){
        
        self.data.removeAll()
        if sqlObj.ExecuteQuery("SELECT * FROM categories ORDER BY name ASC"){
            
            for data in sqlObj.tableData {
                self.data.append(self.createCategoryElement(data: data as! NSDictionary))
            }
            print(data)
        }
        table.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func createCategoryElement(data : NSDictionary) -> Category {
        
        let catObj : Category = Category()
        catObj.id = data.object(forKey: "id") as! String
        catObj.name = data.object(forKey: "name") as! String
        
        return catObj
    }
    // UITableView Delegates
    func tableView(_ tv:UITableView, numberOfRowsInSection section:Int) -> Int {
        let cnt = data.count
        return cnt
    }
    
    func tableView(_ tv:UITableView, cellForRowAt indexPath:IndexPath) -> UITableViewCell {
        let cell = tv.dequeueReusableCell(withIdentifier: "CategoryCell")!
        let cat = data[indexPath.row]
        cell.textLabel?.text = cat.name
        return cell
    }
}

