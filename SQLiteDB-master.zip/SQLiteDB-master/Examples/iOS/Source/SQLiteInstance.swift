//
//  SQLiteInstance.swift
//


import UIKit

class SQLiteInstance: NSObject {

    var     documentsDirectory  : String!
    var     databaseFilename    : String!
    var     databasePath        : String!
    var     tableData           : NSMutableArray!
    var     sqliteDatabase      : OpaquePointer? = nil
    
    //MARK:- setDatabse
    func setDatabse(_ dbFilename:String){
        
        let paths: NSArray = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true) as NSArray
        
        documentsDirectory = paths[0] as! String
        databaseFilename = dbFilename
        databasePath = filePath(dbFilename as NSString) as String
       
        NSLog("path:- %@", databasePath)
        
        let fileManager: FileManager = FileManager.default
        let filename: [String] = dbFilename.components(separatedBy: ".")
        
        if filename.count == 2 {
           
            let dbname: String = filename[0]
            let extenssion: String = filename[1]

            if !fileManager.fileExists(atPath: databasePath) {
               
                let defaultStorePath: String = Bundle.main.path(forResource: dbname, ofType: extenssion)!
                
                if defaultStorePath != "" {
                   
                    var error : NSError?
                    do {
                        try  fileManager.copyItem(atPath: defaultStorePath, toPath: databasePath as String)
                    } catch let error1 as NSError {
                        error = error1
                    }
                    if error != nil{
                        NSLog("Could not copy databse !!!!");
                    }
                }
                
            }else{
                
                // If Exist DB at path
                // check is it updated version or not.
                
                let strBundleDBVersion : String  =  getDatabaseVersion(dbFilename)
                var strLocalDBVersion  : String  =  ""
                
                if ExecuteQuery("SELECT version FROM tbl_db_version"){
                    
                    strLocalDBVersion = (tableData.object(at: 0) as AnyObject).object(forKey: "version") as! String
                }
                
                if strBundleDBVersion != strLocalDBVersion {
                    
                    let defaultStorePath: String = Bundle.main.path(forResource: dbname, ofType: extenssion)!
                    
                    if defaultStorePath != "" {
                        
                        var error : NSError?
                        do {
                            try  fileManager.removeItem(atPath: databasePath as String)
                        } catch let error1 as NSError {
                            error = error1
                        }
                        if error != nil{
                            NSLog("Could not Remove databse !!!!");
                        }
                        
                        do {
                            try  fileManager.copyItem(atPath: defaultStorePath, toPath: databasePath as String)
                        } catch let error1 as NSError {
                            error = error1
                        }
                        if error != nil{
                            NSLog("Could not copy databse !!!!");
                        }
                    }
                }
                
            }
        }
    }
    
    //MARK:- filePath
    func filePath(_ fileName:NSString) -> NSString{
        
        let paths: NSArray = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true) as NSArray
        
        let documentsDir:NSString = paths[0] as! String as NSString
        
        return documentsDir.appendingPathComponent(fileName as String) as NSString
    }
    
    //MARK:- insertDataIntoDB
    func insertDataIntoDB(_ querry:String) -> Bool{
      
        let dbpath  =  databasePath.cString(using: String.Encoding.utf8)
        let cSql = querry.cString(using: String.Encoding.utf8)

        if sqlite3_open(dbpath!,&sqliteDatabase) == SQLITE_OK {
            var stmt:OpaquePointer? = nil
            var result = sqlite3_prepare_v2(sqliteDatabase, cSql!, -1, &stmt, nil)
            
            if result != SQLITE_OK {
                sqlite3_finalize(stmt)
                if let error = String(validatingUTF8: sqlite3_errmsg(sqliteDatabase)) {
                    let msg = "SQLiteDB - failed to prepare SQL: \(sqliteDatabase), Error: \(error)"
                    print(msg)
                }
                return false
            }
            result = sqlite3_step(stmt)
            if result != SQLITE_OK && result != SQLITE_DONE {
                return false
            }else{
                return true
            }
        }
        return false
    }
    
    //MARK:- ExecuteQuery
    func ExecuteQuery(_ querry:String) -> Bool{
        
        let dbpath  =  databasePath.cString(using: String.Encoding.utf8)
        let cSql = querry.cString(using: String.Encoding.utf8)
        
        if sqlite3_open(dbpath!,&sqliteDatabase) == SQLITE_OK {
            
            var stmt:OpaquePointer? = nil
            var result = sqlite3_prepare_v2(sqliteDatabase, cSql!, -1, &stmt, nil)
            
            if result != SQLITE_OK {
                sqlite3_finalize(stmt)
                
                if let error = String(validatingUTF8: sqlite3_errmsg(sqliteDatabase)) {
                    let msg = "SQLiteDB - failed to prepare SQL: \(sqliteDatabase), Error: \(error)"
                    print(msg)
                }
                return false
            }
           // var rows = [SQLRow]()
            var columnCount:CInt = 0
            var columnNames = [String]()
            var columnTypes = [CInt]()
            var fetchColumnInfo = true
            
            tableData  = NSMutableArray()
            result = sqlite3_step(stmt)
            
            while result == SQLITE_ROW {
                
                // Should we get column info?
                if fetchColumnInfo {
                    columnCount = sqlite3_column_count(stmt)
                    for index in 0..<columnCount {
                        // Get column name
                        let name = sqlite3_column_name(stmt, index)
                        columnNames.append(String(cString: name!))
                        // Get column type
                        columnTypes.append(self.getColumnType(index, stmt:stmt!))
                    }
                    fetchColumnInfo = false
                }
                // Get row data for each column
                //let row = SQLRow()
                
                let tableInfo : NSMutableDictionary = NSMutableDictionary()
                
                for index in 0..<columnCount {
                  
                    let key = columnNames[Int(index)]
                    let type = columnTypes[Int(index)]
                    
                    if let val:AnyObject = self.getColumnValue(index, type:type, stmt:stmt!) {
                        //print("Column type:\(type) - key :\(key) value:\(val)")
                        //let col = SQLColumn(value: val, type: type)
                        //row[key] = col
                        tableInfo.setValue(val, forKey: key)
                    }
                }
                if tableInfo.count != 0{
                    tableData.add(tableInfo)
                }
                
                result = sqlite3_step(stmt)
            }
            //NSLog("%@", tableData)
            sqlite3_finalize(stmt)
            
            return true
        }
        return false
    }
    
    //MARK:-
    // Get column value
    fileprivate func getColumnValue(_ index:CInt, type:CInt, stmt:OpaquePointer)->AnyObject? {
        // Integer
        if type == SQLITE_INTEGER {
            let val = sqlite3_column_int(stmt, index)
            return Int(val) as AnyObject?
        }
        // Float
        if type == SQLITE_FLOAT {
            let val = sqlite3_column_double(stmt, index)
            return Double(val) as AnyObject?
        }
        // Text - handled by default handler at end
        // Blob
        /*if type == SQLITE_BLOB {
            let data = sqlite3_column_blob(stmt, index)
            let size = sqlite3_column_bytes(stmt, index)
            let val = Data(bytes: UnsafePointer<UInt8>(data), count: Int(size))
            return val
        }*/
        // Null
        if type == SQLITE_NULL {
            return nil
        }
        // Date
        if type == SQLITE_DATE {
            // Is this a text date
            let txt = String(cString: sqlite3_column_text(stmt, index))
//            let txt = UnsafePointer<Int8>(sqlite3_column_text(stmt, index))
            if txt != nil {
                if let buf = NSString(cString:txt, encoding:String.Encoding.utf8.rawValue) {
                    let set = CharacterSet(charactersIn: "-:")
                    let range = buf.rangeOfCharacter(from: set)
                    if range.location != NSNotFound {
                        // Convert to time
                        var time:tm = tm(tm_sec: 0, tm_min: 0, tm_hour: 0, tm_mday: 0, tm_mon: 0, tm_year: 0, tm_wday: 0, tm_yday: 0, tm_isdst: 0, tm_gmtoff: 0, tm_zone:nil)
                        strptime(txt, "%Y-%m-%d %H:%M:%S", &time)
                        time.tm_isdst = -1
                        let diff = NSTimeZone.local.secondsFromGMT()
                        let t = mktime(&time) + diff
                        let ti = TimeInterval(t)
                        let val = Date(timeIntervalSince1970:ti)
                        return val as AnyObject?
                    }
                }
            }
            // If not a text date, then it's a time interval
            let val = sqlite3_column_double(stmt, index)
            let dt = Date(timeIntervalSince1970: val)
            return dt as AnyObject?
        }
        // If nothing works, return a string representation
        
        let buf = String(cString: sqlite3_column_text(stmt, index))
//        let buf = UnsafePointer<Int8>(sqlite3_column_text(stmt, index))
//        let val = String(cString: buf)
        //		println("SQLiteDB - Got value: \(val)")
        return buf as AnyObject?
    }
    
    //MARK:- getColumnType
    // Get column type
    fileprivate func getColumnType(_ index:CInt, stmt:OpaquePointer)->CInt {
        var type:CInt = 0
        // Column types - http://www.sqlite.org/datatype3.html (section 2.2 table column 1)
        let blobTypes = ["BINARY", "BLOB", "VARBINARY"]
        let charTypes = ["CHAR", "CHARACTER", "CLOB", "NATIONAL VARYING CHARACTER", "NATIVE CHARACTER", "NCHAR", "NVARCHAR", "TEXT", "VARCHAR", "VARIANT", "VARYING CHARACTER"]
        let dateTypes = ["DATE", "DATETIME", "TIME", "TIMESTAMP"]
        let intTypes  = ["BIGINT", "BIT", "BOOL", "BOOLEAN", "INT", "INT2", "INT8", "INTEGER", "MEDIUMINT", "SMALLINT", "TINYINT"]
        let nullTypes = ["NULL"]
        let realTypes = ["DECIMAL", "DOUBLE", "DOUBLE PRECISION", "FLOAT", "NUMERIC", "REAL"]
        // Determine type of column - http://www.sqlite.org/c3ref/c_blob.html
        let buf = sqlite3_column_decltype(stmt, index)
        //		println("SQLiteDB - Got column type: \(buf)")
        if buf != nil {
         
            //var tmp = String.fromCString(buf!)!.uppercased()
            var tmp = String(describing: buf!).uppercased()
            // Remove brackets
            let pos = tmp.positionOf("(")
            //tmp.positionOf("(")
            if pos > 0 {
                tmp = tmp.subStringTo(pos)
            }
            // Remove unsigned?
            // Remove spaces
            // Is the data type in any of the pre-set values?
            //			println("SQLiteDB - Cleaned up column type: \(tmp)")
            
            if intTypes.contains(tmp) {
                return SQLITE_INTEGER
            }
            if realTypes.contains(tmp) {
                return SQLITE_FLOAT
            }
            if charTypes.contains(tmp) {
                return SQLITE_TEXT
            }
            if blobTypes.contains(tmp) {
                return SQLITE_BLOB
            }
            if nullTypes.contains(tmp) {
                return SQLITE_NULL
            }
            if dateTypes.contains(tmp) {
                return SQLITE_DATE
            }
            return SQLITE_TEXT
        } else {
            // For expressions and sub-queries
            type = sqlite3_column_type(stmt, index)
        }
        return type
    }
    //MARK:- Convert_String_From_Response
    func Convert_String_From_Response(_ data:NSDictionary) -> String{
        
        if data.count > 0 {
          
            do {
                let jsonData  = try JSONSerialization.data(withJSONObject: data, options: [])
                //print(jsonData)
                //Convert_Response_From_String(String.init(data: jsonData, encoding: NSUTF8StringEncoding)!)
              return  String.init(data: jsonData, encoding: String.Encoding.utf8)!
            } catch {
                print(error)
                return ""
            }
        }
        return ""
    }
    //MARK:- Convert_Response_From_String
    func Convert_Response_From_String(_ strData:String) -> NSDictionary{
        
        let data : Data = strData.data(using: String.Encoding.utf8)!
        
        do {
            let jsonData  = try JSONSerialization.jsonObject(with: data, options: [])
            print(jsonData)
            return jsonData as! NSDictionary
        } catch {
            print(error)
        }
        return NSDictionary()
    }
    
    func updateTableWithName(_ tableName:String,tableData:NSDictionary,whereClause:String)-> Bool{
        
        var querry      : String = ""
        var countRow    : Int = 0
        var updateValue : String = ""
        
        for (key, value) in tableData {
            if countRow < (tableData.count - 1) {
                if value as! String == "" {
                    updateValue += "\(key) = '', "
                }else{
                    updateValue += "\(key) = '\(value)', "
                }
            }else{
                if value as! String == "" {
                    updateValue += "\(key) = '' "
                }else{
                    updateValue += "\(key) = '\(value)' "
                }
            }
            countRow += 1;
        }

        querry += "UPDATE \(tableName) SET \(updateValue) \(whereClause)"
        
        print(querry)
        
        if ExecuteQuery(querry) {
            print("Successfully Updated Data into \(tableName)")
            return true
        }else{
            print("Could not Updated data into \(tableName)")
            return false
        }
       // return false
    }
    
    //MARK:- insertIntoTable
    func insertIntoTable(_ tableName:String,tableData:NSDictionary)-> Bool{
        
        var querry : String = ""
        
        var keys : String = "("
        var values : String = "("
        var countRow : Int = 0

        var strValue : String = ""
        
        for (key, value) in tableData {
           //'
            strValue = value as! String
            strValue = strValue.replacingOccurrences(of: "'", with: "''")
            
            if countRow < (tableData.count - 1) {
                keys += "\(key),"
                values += "'\(strValue)',"
            }else{
                keys += "\(key)"
                values += "'\(strValue)'"
            }
            countRow += 1;
        }
        
        keys += ")"
        values += ")"

        querry += "insert or replace into \(tableName) \(keys) values\(values)"
        
        print(querry)

        if ExecuteQuery(querry) {
            print("Successfully inserted Data into \(tableName)")
            return true
        }else{
            print("Could not insert data into \(tableName)")
            return false
        }
    }
    
    //MARK:- getCurrentDate
    func getCurrentDate()-> String{
        //2016-03-02 11:58:56
        let querry : String = "SELECT datetime('NOW')"
        
        let dbpath  =  databasePath.cString(using: String.Encoding.utf8)
        let cSql = querry.cString(using: String.Encoding.utf8)
        
        if sqlite3_open(dbpath!,&sqliteDatabase) == SQLITE_OK {
            var stmt:OpaquePointer? = nil
            var result = sqlite3_prepare_v2(sqliteDatabase, cSql!, -1, &stmt, nil)
            if result != SQLITE_OK {
                sqlite3_finalize(stmt)
                
                if let error = String(validatingUTF8: sqlite3_errmsg(sqliteDatabase)) {
                    let msg = "SQLiteDB - failed to prepare SQL: \(sqliteDatabase), Error: \(error)"
                    print(msg)
                }
                return ""
            }
            result = sqlite3_step(stmt)
            while result == SQLITE_ROW {
                let buf = sqlite3_column_text(stmt, 0)
                //let buf = UnsafePointer<Int8>(sqlite3_column_text(stmt, 0))
                //let dateAndTime :  String = String(cString: buf!)
                let dateAndTime :  String = String(describing: buf!)
                print("Current Date : \(dateAndTime)")
                
                return dateAndTime
            }
            sqlite3_finalize(stmt)
        }
        return ""
    }
    
    //MARK:- getDatabaseVersion
    func getDatabaseVersion(_ dbFilename:String)-> String{
        let paths: NSArray = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true) as NSArray
        
        documentsDirectory = paths[0] as! String
        databaseFilename = dbFilename
        databasePath = filePath(dbFilename as NSString) as String
        
        NSLog("path:- %@", databasePath)
        
        let fileManager: FileManager = FileManager.default
        let filename: [String] = dbFilename.components(separatedBy: ".")
        
        if filename.count == 2 {
            
            let dbname: String = filename[0]
            let extenssion: String = filename[1]
            
            let defaultStorePath: String = Bundle.main.path(forResource: dbname, ofType: extenssion)!
            
            if fileManager.fileExists(atPath: defaultStorePath) {
                
                if ExecuteQueryForGetDBVersion("SELECT version FROM tbl_db_version",NSBundleDBPath: defaultStorePath){
                    
                    if let strDBVersion = (tableData.object(at: 0) as AnyObject).object(forKey: "version") as? String{
                        
                        print(strDBVersion)
                        return strDBVersion
                    }
                }
            }
        }
        return ""
    }
    
    //MARK:- ExecuteQueryForGetDBVersion
    func ExecuteQueryForGetDBVersion(_ querry:String,NSBundleDBPath:String) -> Bool{
        
        let dbpath  =  NSBundleDBPath.cString(using: String.Encoding.utf8)
        let cSql = querry.cString(using: String.Encoding.utf8)
        
        if sqlite3_open(dbpath!,&sqliteDatabase) == SQLITE_OK {
            
            var stmt:OpaquePointer? = nil
            var result = sqlite3_prepare_v2(sqliteDatabase, cSql!, -1, &stmt, nil)
            
            if result != SQLITE_OK {
                sqlite3_finalize(stmt)
                
                if let error = String(validatingUTF8: sqlite3_errmsg(sqliteDatabase)) {
                    let msg = "SQLiteDB - failed to prepare SQL: \(sqliteDatabase), Error: \(error)"
                    print(msg)
                }
                return false
            }
            
            // var rows = [SQLRow]()
            
            var columnCount:CInt = 0
            var columnNames = [String]()
            var columnTypes = [CInt]()
            var fetchColumnInfo = true
            
            tableData  = NSMutableArray()
            result = sqlite3_step(stmt)
            
            while result == SQLITE_ROW {
                
                // Should we get column info?
                if fetchColumnInfo {
                    columnCount = sqlite3_column_count(stmt)
                    for index in 0..<columnCount {
                        // Get column name
                        let name = sqlite3_column_name(stmt, index)
                        columnNames.append(String(cString: name!))
                        // Get column type
                        columnTypes.append(self.getColumnType(index, stmt:stmt!))
                    }
                    fetchColumnInfo = false
                }
                // Get row data for each column
                //let row = SQLRow()
                
                let tableInfo : NSMutableDictionary = NSMutableDictionary()
                
                for index in 0..<columnCount {
                    
                    let key = columnNames[Int(index)]
                    let type = columnTypes[Int(index)]
                    
                    if let val:AnyObject = self.getColumnValue(index, type:type, stmt:stmt!) {
                        //print("Column type:\(type) - key :\(key) value:\(val)")
                        //let col = SQLColumn(value: val, type: type)
                        //row[key] = col
                        tableInfo.setValue(val, forKey: key)
                    }
                }
                if tableInfo.count != 0{
                    tableData.add(tableInfo)
                }
                result = sqlite3_step(stmt)
            }
            //NSLog("%@", tableData)
            sqlite3_finalize(stmt)
            
            return true
        }
        return false
    }
    
}

let SQLITE_DATE = SQLITE_NULL + 1
// MARK:- SQLColumn Class - Column Definition
class SQLColumn {
    var value:AnyObject? = nil
    var type:CInt = -1
    
    init(value:AnyObject, type:CInt) {
        //		println("SQLiteDB - Initialize column with type: \(type), value: \(value)")
        self.value = value
        self.type = type
    }
    
    // New conversion functions
    func asString()->String {
        switch (type) {
        case SQLITE_INTEGER, SQLITE_FLOAT:
            return "\(value!)"
            
        case SQLITE_TEXT:
            return value as! String
            
        case SQLITE_BLOB:
            if let str = NSString(data:value as! Data, encoding:String.Encoding.utf8.rawValue) {
                return str as String
            } else {
                return ""
            }
            
        case SQLITE_NULL:
            return ""
            
        case SQLITE_DATE:
            let fmt = DateFormatter()
            fmt.dateFormat = "yyyy-MM-dd HH:mm:ss"
            return fmt.string(from: value as! Date)
            
        default:
            return ""
        }
    }
    
    func asInt()->Int {
        switch (type) {
        case SQLITE_INTEGER, SQLITE_FLOAT:
            return value as! Int
            
        case SQLITE_TEXT:
            let str = value as! NSString
            return str.integerValue
            
        case SQLITE_BLOB:
            if let str = NSString(data:value as! Data, encoding:String.Encoding.utf8.rawValue) {
                return str.integerValue
            } else {
                return 0
            }
            
        case SQLITE_NULL:
            return 0
            
        case SQLITE_DATE:
            return Int((value as! Date).timeIntervalSince1970)
            
        default:
            return 0
        }
    }
    
    func asDouble()->Double {
        switch (type) {
        case SQLITE_INTEGER, SQLITE_FLOAT:
            return value as! Double
            
        case SQLITE_TEXT:
            let str = value as! NSString
            return str.doubleValue
            
        case SQLITE_BLOB:
            if let str = NSString(data:value as! Data, encoding:String.Encoding.utf8.rawValue) {
                return str.doubleValue
            } else {
                return 0.0
            }
            
        case SQLITE_NULL:
            return 0.0
            
        case SQLITE_DATE:
            return (value as! Date).timeIntervalSince1970
            
        default:
            return 0.0
        }
    }
    
    func asData()->Data? {
        switch (type) {
        case SQLITE_INTEGER, SQLITE_FLOAT:
            let str = "\(value)" as NSString
            return str.data(using: String.Encoding.utf8.rawValue)
            
        case SQLITE_TEXT:
            let str = value as! NSString
            return str.data(using: String.Encoding.utf8.rawValue)
            
        case SQLITE_BLOB:
            return value as? Data
            
        case SQLITE_NULL:
            return nil
            
        case SQLITE_DATE:
            let fmt = DateFormatter()
            fmt.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let str = fmt.string(from: value as! Date)
            return str.data(using: String.Encoding.utf8)
            
        default:
            return nil
        }
    }
    
    func asDate()->Date? {
        switch (type) {
        case SQLITE_INTEGER, SQLITE_FLOAT:
            let tm = value as! Double
            return Date(timeIntervalSince1970:tm)
            
        case SQLITE_TEXT:
            let fmt = DateFormatter()
            fmt.dateFormat = "yyyy-MM-dd HH:mm:ss"
            return fmt.date(from: value as! String)
            
        case SQLITE_BLOB:
            if let str = NSString(data:value as! Data, encoding:String.Encoding.utf8.rawValue) {
                let fmt = DateFormatter()
                fmt.dateFormat = "yyyy-MM-dd HH:mm:ss"
                return fmt.date(from: str as String)
            } else {
                return nil
            }
            
        case SQLITE_NULL:
            return nil
            
        case SQLITE_DATE:
            return value as? Date
            
        default:
            return nil
        }
    }
    
    func description()->String {
        return "Type: \(type), Value: \(value)"
    }
}
// MARK:- SQLRow Class - Row Definition
class SQLRow {
   
    var data = Dictionary<String, SQLColumn>()
    
    subscript(key: String) -> SQLColumn? {
        get {
            return data[key]
        }
        
        set(newVal) {
            data[key] = newVal
        }
    }
    
    func description()->String {
        return data.description
    }
    
}

extension String {
   
    func positionOf(_ sub:String)->Int {
        var pos = -1
        if let range = self.range(of: sub) {
            if !range.isEmpty {
                pos = self.characters.distance(from: self.startIndex, to: range.lowerBound)
            }
        }
        return pos
    }
    
    func subStringTo(_ pos:Int)->String {
        var substr = ""
        let end = self.characters.index(self.startIndex, offsetBy: pos-1)
        let range = self.startIndex...end
        substr = self[range]
        return substr
    }
}
