How-to-use-SQLite-Database-in-Swift
===================================

In this tutorial we cover how to use SQLite database in Swift. This is an example showing how to create a application that performs Insert, Update, Delete operation on a table called StudentInfo.

You can find complete tutorial on how to use this code repo here : <a target="_blank" href="http://www.theappguruz.com/blog/use-sqlite-database-swift">How to use SQLite Database in Swift</a>

This Tutorial has been presented by The App Guruz - One of the best <a href="http://www.theappguruz.com/mobile-application-development/">Mobile Application Development Company in India</a>
