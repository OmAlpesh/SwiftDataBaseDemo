//
//  Category.swift
//  SQLiteDB-iOS


#if os(iOS)
	import UIKit
#else
	import AppKit
#endif

class Category:SQLiteInstance {
	
    var id : String = ""
    var name : String = ""
	
}
