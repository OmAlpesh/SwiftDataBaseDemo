//
//  AddCategoryViewController.swift
//  SQLiteDB-iOS
//


import UIKit

class AddCategoryViewController: UITableViewController {
    @IBOutlet var txtCat: UITextField!
    
    @IBAction func save() {
        
        // Hide keyboard
        if txtCat.isFirstResponder {
            txtCat.resignFirstResponder()
        }
        // Validations
        if txtCat.text!.isEmpty {
            let alert = UIAlertView(title:"SQLiteDB", message:"Please add a category name first!", delegate:nil, cancelButtonTitle: "OK")
            alert.show()
        }
        
        //DB initialize
        let sqlObj = SQLiteInstance()
        sqlObj.setDatabse("data.db")

        // Save task
        let postData : NSMutableDictionary = NSMutableDictionary()
        postData.setValue(txtCat.text,        forKey: "name")
        
        NSLog("Post Data : %@", postData)
        if sqlObj.insertIntoTable("categories", tableData: postData){
            
            NSLog("Succefully inserted data into `categories`")
            let alert = UIAlertView(title:"SQLiteDB", message:"Category successfully saved!", delegate:nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else{
            
            print("data could not be inserted into `categories`")
        }
    }
}
