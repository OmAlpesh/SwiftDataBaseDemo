//
//  ModelManager.swift
//  DataBaseDemo
//
//  Created by Krupa-iMac on 05/08/14.
//  Copyright (c) 2014 TheAppGuruz. All rights reserved.
//

import UIKit

let sharedInstance = ModelManager()

class ModelManager: NSObject {
    
     //MARK: - DataBase Modal
    var database: FMDatabase? = nil

    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            sharedInstance.database = FMDatabase(path: Util.getPath("Student.sqlite"))
        }
        return sharedInstance
    }
    
    //MARK: - Student Modal
    func addStudentData(_ studentInfo: StudentInfo) -> Bool {
        sharedInstance.database!.open()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO student_info (Name, Marks) VALUES (?, ?)", withArgumentsIn: [studentInfo.Name, studentInfo.Marks])
        sharedInstance.database!.close()
        return isInserted
    }
   
    func updateStudentData(_ studentInfo: StudentInfo) -> Bool {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE student_info SET Name=?, Marks=? WHERE RollNo=?", withArgumentsIn: [studentInfo.Name, studentInfo.Marks, studentInfo.RollNo])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    func deleteStudentData(_ studentInfo: StudentInfo) -> Bool {
        sharedInstance.database!.open()
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM student_info WHERE RollNo=?", withArgumentsIn: [studentInfo.RollNo])
        sharedInstance.database!.close()
        return isDeleted
    }

    func getAllStudentData() -> NSMutableArray {
        sharedInstance.database!.open()
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM student_info", withArgumentsIn: nil)
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                let studentInfo : StudentInfo = StudentInfo()
                studentInfo.RollNo = resultSet.string(forColumn: "RollNo")
                studentInfo.Name = resultSet.string(forColumn: "Name")
                studentInfo.Marks = resultSet.string(forColumn: "Marks")
                marrStudentInfo.add(studentInfo)
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
    }
    
    //MARK: - Score Modal
    func addSCoreData(_ ScoreInfo: ScoreInfo) -> Bool {
        sharedInstance.database!.open()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO ScoreTbl (Id, Name, Score) VALUES (?, ?, ?)", withArgumentsIn: [ScoreInfo.playerId, ScoreInfo.playperName, ScoreInfo.playerScore])
        sharedInstance.database!.close()
        return isInserted
    }
    func getAllSCoreData(id: String) -> NSMutableArray {
        sharedInstance.database!.open()
        
     let Qurey = "SELECT * FROM ScoreTbl WHERE ID = \(id)"
       
     print(Qurey)
        
      let resultSet: FMResultSet! = sharedInstance.database!.executeQuery(Qurey, withArgumentsIn: nil)
        
        
       // let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM ScoreTbl", withArgumentsIn: nil)
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                let scoreInfoVar : ScoreInfo = ScoreInfo()
                scoreInfoVar.playerId = resultSet.string(forColumn: "ID")
                scoreInfoVar.playperName = resultSet.string(forColumn: "Name")
                scoreInfoVar.playerScore = resultSet.string(forColumn: "Score")
                marrStudentInfo.add(scoreInfoVar)
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
    }

    
    func updateSCoreData(_ studentInfo: StudentInfo) -> Bool {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE student_info SET Name=?, Marks=? WHERE RollNo=?", withArgumentsIn: [studentInfo.Name, studentInfo.Marks, studentInfo.RollNo])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    func deleteSCoreData(_ studentInfo: StudentInfo) -> Bool {
        sharedInstance.database!.open()
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM student_info WHERE RollNo=?", withArgumentsIn: [studentInfo.RollNo])
        sharedInstance.database!.close()
        return isDeleted
    }
    
    
}
