//
//  AddTaskViewController.swift
//  SQLiteDB-iOS
//


import UIKit

class AddTaskViewController: UITableViewController {
	@IBOutlet var txtTask: UITextField!

	@IBAction func save() {
		// Hide keyboard
		if txtTask.isFirstResponder {
			txtTask.resignFirstResponder()
		}
		// Validations
		if txtTask.text!.isEmpty {
			let alert = UIAlertView(title:"SQLiteDB", message:"Please add a task description first!", delegate:nil, cancelButtonTitle: "OK")
			alert.show()
		}
        //DB initialize
        let sqlObj = SQLiteInstance()
        sqlObj.setDatabse("data.db")
        
        // Save task
        let postData : NSMutableDictionary = NSMutableDictionary()
        postData.setValue("-1",   forKey: "categoryID")
        postData.setValue(txtTask.text,        forKey: "task")
        
        NSLog("Post Data : %@", postData)
        if sqlObj.insertIntoTable("tasks", tableData: postData){
            
            NSLog("Succefully inserted data into `Tasks`")
            let alert = UIAlertView(title:"SQLiteDB", message:"Task successfully saved!", delegate:nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else{
            
            print("data could not be inserted into `categories`")
        }
	}
}
