//
//  TasksViewController.swift
//  SQLiteDB-iOS
//


import UIKit

class TasksViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
	@IBOutlet var table:UITableView!
	var data = [Task]()
    let sqlObj = SQLiteInstance()
	
	override func viewDidLoad() {
		super.viewDidLoad()
        
	}

	override func viewWillAppear(_ animated:Bool) {
		super.viewWillAppear(animated)
        
        sqlObj.setDatabse("data.db")
        displayDetails()
	}
    
	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
	}

    func displayDetails(){
        
        self.data.removeAll()
        if sqlObj.ExecuteQuery("SELECT * FROM tasks ORDER BY id ASC"){
            
            for data in sqlObj.tableData {
                self.data.append(self.createTaskElement(data: data as! NSDictionary))
            }
            
            print(data)
        }
        table.reloadData()
    }
    func createTaskElement(data : NSDictionary) -> Task {
        
        let taskObj : Task = Task()
        taskObj.id = data.object(forKey: "id") as! String
        taskObj.task = data.object(forKey: "task") as! String
        taskObj.categoryID = data.object(forKey: "categoryID") as! String
        
        return taskObj
    }
    
	// UITableView Delegates
	func tableView(_ tv:UITableView, numberOfRowsInSection section:Int) -> Int {
		//let cnt = data.count
        return data.count
	}
	
	func tableView(_ tv:UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		let cell = tv.dequeueReusableCell(withIdentifier: "TaskCell")!
		let task = data[indexPath.row]
		cell.textLabel?.text = task.task
		return cell
	}
}

