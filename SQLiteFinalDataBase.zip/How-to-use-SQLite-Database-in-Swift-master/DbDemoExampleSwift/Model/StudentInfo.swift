//
//  StudentInfo.swift
//  DataBaseDemo
//
//  Created by Krupa-iMac on 05/08/14.
//  Copyright (c) 2014 TheAppGuruz. All rights reserved.
//

import UIKit

class StudentInfo: NSObject {
    
    var RollNo: String = String()
    var Name: String = String()
    var Marks: String = String()
   
}
