SQLiteDB 
========

This is a simple and lightweight SQLite wrapper for Swift. It allows all basic SQLite functionality including being able to bind values to parameters in an SQL statement. The framework does require an initial SQLite database to be included in your project - it does not create the database for you via code.


Adding to Your Project
---
* Create your SQLite database however you like, but name it `data.db` and then add the `data.db` file to your Xcode project.

**Note:** Remember to add the database file above to your application target when you add it to the project. If you don't add the database file to a project target, it will not be copied to the device along with the other project resources.

* Add all of the included source files (except for README.md, of course) to your project.

* If you don't have a bridging header file, use the included `Bridging-Header.h` file. If you already have a bridging header file, then copy the contents from the included `Bridging-Header.h` file to your own bridging header file.

* If you didn't have a bridging header file, make sure that you modify your project settings to point to the new bridging header file. This will be under  **Build Settings** for your target and will be named **Objective-C Bridging Header**.

* Add the SQLite library (libsqlite3.0.dylib or libsqlite3.tbd) to your project under **Build Phases** - **Link Binary With Libraries** section.

That's it. You're set!

Usage
---
* You can gain access to the shared database instance as follows:
```swift
//DB initialize
let sqlObj = SQLiteInstance()
sqlObj.setDatabse("data.db")
```

In the above, `db` is a reference to the shared SQLite database instance. You can access a column from your query results by subscripting a row of the returned results (the rows are dictionaries) based on the column name. That returns an `AnyObject` value which you can cast to the relevant data type.

* Of course, you can also construct the above SQL query by using Swift's string manipulation functionality as well using the `ExecuteQuery` method: (without using the SQLite bind functionality):
```swift
    if sqlObj.ExecuteQuery("SELECT * FROM tasks ORDER BY id ASC"){}
// If the result is 0 then the operation failed,
```

* You can execute all non-query SQL commands (INSERT, DELETE, UPDATE etc.) using the `ExecuteQuery` method:
```swift
    let postData : NSMutableDictionary = NSMutableDictionary()
    postData.setValue("-1",   forKey: "categoryID")
    postData.setValue(txtTask.text,        forKey: "task")
    if sqlObj.insertIntoTable("tasks", tableData: postData){//Success}else{//Failed}
// If the result is 0 then the operation failed, Otherwise it inserts the record into the table with success
```


* If you would prefer to model your database tables as classes, SQLiteDB also provides an `SQLiteInstance` class which does most of the heavy lifting for you. If you create a sub-class of `SQLiteInstance`, define properties where the names match the column names in your SQLite table, then you can use the sub-class to save to/update the database without having to write all the necessary boilerplate code yourself. Refer to the sample iOS project for details about how to implement this.





