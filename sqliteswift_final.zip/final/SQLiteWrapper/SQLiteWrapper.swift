//
//  SQLiteWrapper.swift
//  SQLiteTutorial
//
//  Created by Chris Wagner on 11/26/15.
//  Copyright © 2015 Razeware LLC. All rights reserved.
//

import Foundation
import SQLite